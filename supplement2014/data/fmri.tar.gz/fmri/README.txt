(10/24/'13)

This directory contains resting state fMRI BOLD data and demographics data (including diagnostic group). The demographics data is contained in the file "Demographics.csv". These data were used in the paper "Describing high-order statistical dependence using 'Concurrence Topology', with application to functional MRI brain data" by Ellis and Klein (2013). These data were found and prepared by Arno Klein.

The BOLD data is given in separate files. There are 66 files, "*_BOLDfMRI.csv", one for each subject. In each file there are BOLD values for 92 regions (the rows). There are 193 columns. The first column gives the FreeSurfer region code, the rest are BOLD values. Columns 2 through 193 correspond to time points.

The data were generated at New York University and distributed as part of the 1000 Functional Connectomes project  
(http://fcon_1000.projects.nitrc.org/). This data set includes 41 healthy controls 
("NewYork_a_part1") and 25 adults diagnosed with ADHD ("NewYork_a_ADHD").

The file "BrainImageProcessing.pdf" in this directory explains how the regional BOLD values were computed. The file "FreeSurferRegions.txt" translates the FreeSurfer region codes and provides some information about them.
